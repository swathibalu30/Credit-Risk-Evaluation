"""
Credit Risk Evaluation System - Streamlit Application
Interactive web interface for training models and predicting loan default risk.
"""

import streamlit as st
import pandas as pd
import os
import json
import time
from datetime import datetime
import plotly.graph_objects as go
import plotly.express as px

# Import custom modules
from model_training_sklearn import train_model_from_csv
from predict_sklearn import get_predictor


# ========================================
# PAGE CONFIGURATION
# ========================================
st.set_page_config(
    page_title="Credit Risk Evaluation System",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ========================================
# CUSTOM CSS STYLING
# ========================================
st.markdown("""
    <style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #555;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-box {
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
        border-left: 5px solid #1f77b4;
    }
    .success-box {
        background-color: #d4edda;
        padding: 20px;
        border-radius: 10px;
        border-left: 5px solid #28a745;
        color: #155724;
    }
    .danger-box {
        background-color: #f8d7da;
        padding: 20px;
        border-radius: 10px;
        border-left: 5px solid #dc3545;
        color: #721c24;
    }
    .warning-box {
        background-color: #fff3cd;
        padding: 20px;
        border-radius: 10px;
        border-left: 5px solid #ffc107;
        color: #856404;
    }
    .info-box {
        background-color: #d1ecf1;
        padding: 20px;
        border-radius: 10px;
        border-left: 5px solid #17a2b8;
        color: #0c5460;
    }
    </style>
    """, unsafe_allow_html=True)


# ========================================
# SESSION STATE INITIALIZATION
# ========================================
if 'model_trained' not in st.session_state:
    st.session_state.model_trained = False
if 'training_results' not in st.session_state:
    st.session_state.training_results = None
if 'metadata' not in st.session_state:
    st.session_state.metadata = None
if 'predictor' not in st.session_state:
    st.session_state.predictor = None


# ========================================
# HELPER FUNCTIONS
# ========================================

def check_existing_model():
    """Check if a trained model already exists."""
    return os.path.exists("risk_model.pkl") and os.path.exists("model_metadata.json")


def load_existing_model_info():
    """Load information about existing trained model."""
    try:
        with open('model_metadata.json', 'r') as f:
            return json.load(f)
    except:
        return None


def create_gauge_chart(value, title):
    """Create a gauge chart for displaying metrics."""
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=value * 100,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title, 'font': {'size': 20}},
        delta={'reference': 50},
        gauge={
            'axis': {'range': [None, 100], 'tickwidth': 1, 'tickcolor': "darkblue"},
            'bar': {'color': "darkblue"},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, 50], 'color': '#d4edda'},
                {'range': [50, 75], 'color': '#fff3cd'},
                {'range': [75, 100], 'color': '#f8d7da'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 75
            }
        }
    ))
    
    fig.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig


def create_feature_importance_chart(feature_importance, top_n=10):
    """Create a horizontal bar chart for feature importance."""
    # Get top N features
    sorted_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)[:top_n]
    
    features = [f[0] for f in sorted_features]
    importance = [f[1] for f in sorted_features]
    
    fig = go.Figure(go.Bar(
        x=importance,
        y=features,
        orientation='h',
        marker=dict(
            color=importance,
            colorscale='Blues',
            showscale=True
        ),
        text=[f'{v:.4f}' for v in importance],
        textposition='auto',
    ))
    
    fig.update_layout(
        title=f'Top {top_n} Most Important Features',
        xaxis_title='Importance Score',
        yaxis_title='Features',
        height=400,
        margin=dict(l=150, r=20, t=50, b=20),
        yaxis={'categoryorder': 'total ascending'}
    )
    
    return fig


def create_metrics_chart(results):
    """Create a bar chart comparing different metrics."""
    metrics = {
        'Accuracy': results['accuracy'],
        'AUC-ROC': results['auc'],
        'Precision': results['precision'],
        'Recall': results['recall'],
        'F1 Score': results['f1_score']
    }
    
    fig = go.Figure(go.Bar(
        x=list(metrics.keys()),
        y=list(metrics.values()),
        marker=dict(
            color=list(metrics.values()),
            colorscale='Viridis',
            showscale=True,
            cmin=0,
            cmax=1
        ),
        text=[f'{v:.4f}' for v in metrics.values()],
        textposition='auto',
    ))
    
    fig.update_layout(
        title='Model Performance Metrics',
        xaxis_title='Metric',
        yaxis_title='Score',
        yaxis=dict(range=[0, 1.1]),
        height=400,
        margin=dict(l=50, r=20, t=50, b=50)
    )
    
    return fig


# ========================================
# MAIN APPLICATION
# ========================================

def main():
    """Main application function."""
    
    # Header
    st.markdown('<p class="main-header">💳 Credit Risk Evaluation System</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Predicting Loan Default Using PySpark & Machine Learning</p>', unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Sidebar
    with st.sidebar:
        st.image("https://img.icons8.com/fluency/96/000000/bank-card-back-side.png", width=80)
        st.title("📋 Navigation")
        
        page = st.radio(
            "Choose a section:",
            ["🏠 Home", "📊 Train Model", "🔮 Make Predictions"],
            index=0
        )
        
        st.markdown("---")
        
        # Model Status
        st.subheader("📌 Model Status")
        if check_existing_model():
            st.success("✅ Model Available")
            metadata = load_existing_model_info()
            if metadata:
                st.info(f"**Target:** {metadata.get('target_column', 'N/A')}")
                st.info(f"**Features:** {len(metadata.get('numerical_cols', [])) + len(metadata.get('categorical_cols', []))}")
        else:
            st.warning("⚠️ No Model Trained")
        
        st.markdown("---")
        
        # About
        st.subheader("ℹ️ About")
        st.info(
            "This system uses PySpark and Random Forest to predict credit risk. "
            "Upload your dataset to train a model, then use it to evaluate loan applications."
        )
        
        st.markdown("---")
        st.caption(f"© 2025 Credit Risk System")
    
    # ========================================
    # PAGE: HOME
    # ========================================
    if page == "🏠 Home":
        st.header("🏠 Welcome to Credit Risk Evaluation System")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("""
            <div class="info-box">
                <h3>📊 Step 1: Upload Dataset</h3>
                <p>Upload your loan dataset in CSV format. The system will automatically detect features and target column.</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown("""
            <div class="info-box">
                <h3>🤖 Step 2: Train Model</h3>
                <p>The system trains a RandomForest classifier using PySpark MLlib with automatic preprocessing.</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown("""
            <div class="info-box">
                <h3>🔮 Step 3: Predict Risk</h3>
                <p>Enter loan application details to get real-time risk assessment and probability scores.</p>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        st.subheader("📋 Dataset Requirements")
        st.markdown("""
        Your CSV dataset should include:
        - **Target Column**: Binary indicator for loan default (e.g., 'default', 'loan_status', 'status')
        - **Numerical Features**: Income, loan amount, age, credit score, etc.
        - **Categorical Features**: Employment type, education, purpose, etc.
        
        **Example columns**: `age`, `income`, `loan_amount`, `employment_type`, `credit_score`, `default`
        """)
        
        st.markdown("---")
        
        st.subheader("🚀 Getting Started")
        st.info("👈 Use the navigation menu on the left to train your model or make predictions!")
    
    # ========================================
    # PAGE: TRAIN MODEL
    # ========================================
    elif page == "📊 Train Model":
        st.header("📊 Train Credit Risk Model")
        
        st.markdown("""
        <div class="warning-box">
            <strong>⚠️ Important:</strong> Upload a CSV file containing your loan dataset. 
            The model will be trained on this data using PySpark's RandomForest classifier.
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("###")
        
        # File Uploader
        uploaded_file = st.file_uploader(
            "📁 Upload Loan Dataset (CSV)",
            type=['csv'],
            help="Upload a CSV file containing loan data with features and target column"
        )
        
        if uploaded_file is not None:
            # Display file info
            st.success(f"✅ File uploaded: **{uploaded_file.name}**")
            
            # Show data preview
            with st.expander("👁️ Preview Dataset", expanded=True):
                try:
                    df_preview = pd.read_csv(uploaded_file)
                    st.dataframe(df_preview.head(10), use_container_width=True)
                    
                    col1, col2, col3 = st.columns(3)
                    col1.metric("📊 Total Rows", len(df_preview))
                    col2.metric("📋 Total Columns", len(df_preview.columns))
                    col3.metric("💾 File Size", f"{uploaded_file.size / 1024:.2f} KB")
                    
                    # Reset file pointer for training
                    uploaded_file.seek(0)
                except Exception as e:
                    st.error(f"Error reading file: {str(e)}")
            
            st.markdown("###")
            
            # Target column selection
            target_column = st.text_input(
                "🎯 Target Column Name (optional)",
                value="default",
                help="Name of the column indicating loan default. Leave as 'default' for auto-detection."
            )
            
            st.markdown("###")
            
            # Train button
            if st.button("🚀 Start Model Training", type="primary", use_container_width=True):
                # Save uploaded file temporarily
                temp_file_path = "temp_dataset.csv"
                with open(temp_file_path, "wb") as f:
                    f.write(uploaded_file.getvalue())
                
                # Training progress
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                try:
                    status_text.text("🔄 Initializing training process...")
                    progress_bar.progress(10)
                    time.sleep(0.5)
                    
                    status_text.text("📊 Loading and preprocessing data...")
                    progress_bar.progress(30)
                    
                    # Train the model
                    with st.spinner("🌲 Training RandomForest model... This may take a few minutes."):
                        results = train_model_from_csv(temp_file_path, target_column)
                        progress_bar.progress(90)
                    
                    status_text.text("✅ Training completed!")
                    progress_bar.progress(100)
                    time.sleep(0.5)
                    
                    # Store results in session state
                    st.session_state.model_trained = True
                    st.session_state.training_results = results
                    st.session_state.metadata = load_existing_model_info()
                    
                    # Clear progress indicators
                    progress_bar.empty()
                    status_text.empty()
                    
                    # Success message
                    st.markdown("""
                    <div class="success-box">
                        <h2>🎉 Model Training Completed Successfully!</h2>
                        <p>Your credit risk model has been trained and saved. You can now use it to make predictions.</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    st.markdown("###")
                    
                    # Display metrics
                    st.subheader("📈 Model Performance Metrics")
                    
                    # Metric cards
                    col1, col2, col3, col4, col5 = st.columns(5)
                    
                    with col1:
                        st.metric(
                            "🎯 Accuracy",
                            f"{results['accuracy']:.4f}",
                            f"{results['accuracy']*100:.2f}%"
                        )
                    
                    with col2:
                        st.metric(
                            "📊 AUC-ROC",
                            f"{results['auc']:.4f}",
                            f"{results['auc']*100:.2f}%"
                        )
                    
                    with col3:
                        st.metric(
                            "🎲 Precision",
                            f"{results['precision']:.4f}",
                            f"{results['precision']*100:.2f}%"
                        )
                    
                    with col4:
                        st.metric(
                            "🔄 Recall",
                            f"{results['recall']:.4f}",
                            f"{results['recall']*100:.2f}%"
                        )
                    
                    with col5:
                        st.metric(
                            "⚖️ F1 Score",
                            f"{results['f1_score']:.4f}",
                            f"{results['f1_score']*100:.2f}%"
                        )
                    
                    st.markdown("###")
                    
                    # Visualizations
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.plotly_chart(
                            create_metrics_chart(results),
                            use_container_width=True
                        )
                    
                    with col2:
                        st.plotly_chart(
                            create_feature_importance_chart(results['feature_importance'], top_n=10),
                            use_container_width=True
                        )
                    
                    st.markdown("###")
                    
                    # Training details
                    with st.expander("📊 Detailed Training Information"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write("**Dataset Split:**")
                            st.write(f"- Training samples: {results['train_size']}")
                            st.write(f"- Testing samples: {results['test_size']}")
                            st.write(f"- Total features: {results['total_features']}")
                        
                        with col2:
                            st.write("**Feature Types:**")
                            st.write(f"- Numerical features: {len(results['numerical_features'])}")
                            st.write(f"- Categorical features: {len(results['categorical_features'])}")
                            st.write(f"- Target column: {results['target_column']}")
                        
                        st.write("**Numerical Features:**")
                        st.write(", ".join(results['numerical_features']))
                        
                        st.write("**Categorical Features:**")
                        st.write(", ".join(results['categorical_features']) if results['categorical_features'] else "None")
                    
                    # Clean up
                    os.remove(temp_file_path)
                    
                except Exception as e:
                    st.error(f"❌ Error during training: {str(e)}")
                    import traceback
                    with st.expander("🔍 Error Details"):
                        st.code(traceback.format_exc())
                    
                    # Clean up
                    if os.path.exists(temp_file_path):
                        os.remove(temp_file_path)
        
        else:
            st.info("👆 Please upload a CSV file to begin training.")
    
    # ========================================
    # PAGE: MAKE PREDICTIONS
    # ========================================
    elif page == "🔮 Make Predictions":
        st.header("🔮 Credit Risk Prediction")
        
        # Check if model exists
        if not check_existing_model():
            st.markdown("""
            <div class="warning-box">
                <h3>⚠️ No Model Available</h3>
                <p>Please train a model first by uploading a dataset in the <strong>Train Model</strong> section.</p>
            </div>
            """, unsafe_allow_html=True)
            return
        
        # Load model metadata
        if st.session_state.metadata is None:
            st.session_state.metadata = load_existing_model_info()
        
        metadata = st.session_state.metadata
        
        if metadata is None:
            st.error("❌ Unable to load model metadata. Please retrain the model.")
            return
        
        st.success("✅ Model loaded and ready for predictions!")
        
        # Show model info
        with st.expander("ℹ️ Model Information"):
            col1, col2, col3 = st.columns(3)
            col1.metric("🎯 Target", metadata['target_column'])
            col2.metric("📊 Features", len(metadata['numerical_cols']) + len(metadata['categorical_cols']))
            col3.metric("🔢 Numerical", len(metadata['numerical_cols']))
        
        st.markdown("---")
        
        st.subheader("📝 Enter Loan Application Details")
        
        # Create dynamic input form
        input_dict = {}
        
        # Numerical inputs
        if metadata['numerical_cols']:
            st.markdown("#### 🔢 Numerical Features")
            
            # Create columns for better layout
            num_cols = metadata['numerical_cols']
            cols_per_row = 3
            
            for i in range(0, len(num_cols), cols_per_row):
                cols = st.columns(cols_per_row)
                for j, col_name in enumerate(num_cols[i:i+cols_per_row]):
                    with cols[j]:
                        input_dict[col_name] = st.number_input(
                            f"📊 {col_name.replace('_', ' ').title()}",
                            value=0.0,
                            step=0.01,
                            format="%.2f"
                        )
        
        # Categorical inputs
        if metadata['categorical_cols']:
            st.markdown("#### 📋 Categorical Features")
            
            cat_cols = metadata['categorical_cols']
            cols_per_row = 3
            
            for i in range(0, len(cat_cols), cols_per_row):
                cols = st.columns(cols_per_row)
                for j, col_name in enumerate(cat_cols[i:i+cols_per_row]):
                    with cols[j]:
                        input_dict[col_name] = st.text_input(
                            f"📝 {col_name.replace('_', ' ').title()}",
                            value=""
                        )
        
        st.markdown("###")
        
        # Predict button
        if st.button("🔮 Predict Credit Risk", type="primary", use_container_width=True):
            with st.spinner("🔄 Analyzing credit risk..."):
                try:
                    # Get predictor
                    predictor = get_predictor()
                    
                    # Make prediction
                    result = predictor.predict_risk(input_dict)
                    
                    # Check for errors
                    if 'error' in result:
                        st.error(f"❌ Prediction failed: {result['error']}")
                        return
                    
                    st.markdown("###")
                    
                    # Display results with color coding
                    if result['risk_class'] == "High Risk":
                        st.markdown(f"""
                        <div class="danger-box">
                            <h2>⚠️ High Credit Risk Detected</h2>
                            <h3>Risk Score: {result['risk_percentage']:.2f}%</h3>
                            <p>This loan application has a high probability of default.</p>
                        </div>
                        """, unsafe_allow_html=True)
                    else:
                        st.markdown(f"""
                        <div class="success-box">
                            <h2>✅ Low Credit Risk</h2>
                            <h3>Risk Score: {result['risk_percentage']:.2f}%</h3>
                            <p>This loan application has a low probability of default.</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    st.markdown("###")
                    
                    # Detailed metrics
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.plotly_chart(
                            create_gauge_chart(result['risk_score'], "Risk Score"),
                            use_container_width=True
                        )
                    
                    with col2:
                        st.metric(
                            "🎯 Prediction",
                            result['risk_class'],
                            f"{'High' if result['prediction'] == 1 else 'Low'} Risk"
                        )
                        st.metric(
                            "📊 Confidence",
                            f"{result['confidence_percentage']:.2f}%",
                            f"{result['confidence']:.4f}"
                        )
                    
                    with col3:
                        # Probability breakdown
                        st.markdown("**Probability Breakdown:**")
                        st.progress(result['low_risk_probability'])
                        st.write(f"✅ Low Risk: {result['low_risk_probability']*100:.2f}%")
                        st.progress(result['high_risk_probability'])
                        st.write(f"⚠️ High Risk: {result['high_risk_probability']*100:.2f}%")
                    
                    st.markdown("###")
                    
                    # Detailed results
                    with st.expander("📊 Detailed Prediction Results"):
                        st.json(result)
                    
                    st.markdown("###")
                    
                    # Download prediction results
                    st.subheader("📥 Download Prediction Report")
                    
                    # Prepare download data
                    download_data = {
                        'Prediction Date': [datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
                        'Risk Class': [result['risk_class']],
                        'Risk Score (%)': [f"{result['risk_percentage']:.2f}"],
                        'Confidence (%)': [f"{result['confidence_percentage']:.2f}"],
                        'Low Risk Probability (%)': [f"{result['low_risk_probability']*100:.2f}"],
                        'High Risk Probability (%)': [f"{result['high_risk_probability']*100:.2f}"],
                        'Prediction': [result['prediction']]
                    }
                    
                    # Add input features to download
                    for key, value in input_dict.items():
                        download_data[f"Input: {key}"] = [value]
                    
                    # Create DataFrame
                    download_df = pd.DataFrame(download_data)
                    
                    # Convert to CSV
                    csv = download_df.to_csv(index=False).encode('utf-8')
                    
                    # Download button
                    col1, col2 = st.columns([2, 1])
                    with col1:
                        st.download_button(
                            label="📥 Download Prediction Report (CSV)",
                            data=csv,
                            file_name=f"credit_risk_prediction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                            mime="text/csv",
                            use_container_width=True
                        )
                    
                    with col2:
                        # Convert to Excel format
                        import io
                        excel_buffer = io.BytesIO()
                        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                            download_df.to_excel(writer, index=False, sheet_name='Prediction')
                        excel_data = excel_buffer.getvalue()
                        
                        st.download_button(
                            label="📥 Download Report (Excel)",
                            data=excel_data,
                            file_name=f"credit_risk_prediction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            use_container_width=True
                        )
                    
                except Exception as e:
                    st.error(f"❌ Prediction error: {str(e)}")
                    import traceback
                    with st.expander("🔍 Error Details"):
                        st.code(traceback.format_exc())


# ========================================
# RUN APPLICATION
# ========================================
if __name__ == "__main__":
    main()
