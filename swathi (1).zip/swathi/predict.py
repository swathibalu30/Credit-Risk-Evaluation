"""
Credit Risk Prediction Module
This module handles real-time prediction using the trained PySpark model.
"""

from pyspark.sql import SparkSession
from pyspark.ml import PipelineModel
import json
import os


class RiskPredictor:
    """
    Class to handle credit risk predictions using saved PySpark model.
    """
    
    def __init__(self):
        """Initialize the predictor by loading saved model and metadata."""
        self.spark = None
        self.model = None
        self.metadata = None
        self.is_loaded = False
    
    def load_model(self):
        """
        Load the saved PySpark model and metadata.
        
        Returns:
            bool: True if model loaded successfully, False otherwise
        """
        try:
            # Check if model exists
            if not os.path.exists("risk_model"):
                print("❌ Model not found. Please train the model first.")
                return False
            
            # Initialize Spark Session
            print("📊 Initializing Spark Session for prediction...")
            
            import os
            import findspark
            findspark.init()
            
            self.spark = SparkSession.builder \
                .appName("CreditRiskPrediction") \
                .master("local[*]") \
                .getOrCreate()
            
            self.spark.sparkContext.setLogLevel("ERROR")
            
            # Load the trained model pipeline
            print("📂 Loading trained model...")
            self.model = PipelineModel.load("risk_model")
            
            # Load metadata
            with open('model_metadata.json', 'r') as f:
                self.metadata = json.load(f)
            
            print("✅ Model loaded successfully!")
            self.is_loaded = True
            return True
            
        except Exception as e:
            print(f"❌ Error loading model: {str(e)}")
            return False
    
    def predict_risk(self, input_dict):
        """
        Predict credit risk for a given input.
        
        Args:
            input_dict (dict): Dictionary containing feature values
                              Keys should match the column names from training
        
        Returns:
            dict: Dictionary containing:
                - risk_score: Probability of default (0-1)
                - risk_percentage: Risk score as percentage
                - risk_class: "High Risk" or "Low Risk"
                - prediction: Binary prediction (1 = High Risk, 0 = Low Risk)
                - confidence: Confidence level of prediction
        """
        
        if not self.is_loaded:
            print("⚠️  Model not loaded. Loading now...")
            if not self.load_model():
                return {
                    'error': 'Model could not be loaded. Please train the model first.'
                }
        
        try:
            print("\n🔮 Making prediction...")
            
            # ========================================
            # STEP 1: Prepare Input Data
            # ========================================
            print("   - Preparing input data...")
            
            # Get expected columns (excluding target)
            target_column = self.metadata['target_column']
            numerical_cols = self.metadata['numerical_cols']
            categorical_cols = self.metadata['categorical_cols']
            
            # Create a complete input dictionary with all required columns
            complete_input = {}
            
            # Add numerical features
            for col in numerical_cols:
                if col in input_dict:
                    # Convert to appropriate type
                    try:
                        complete_input[col] = float(input_dict[col])
                    except (ValueError, TypeError):
                        complete_input[col] = 0.0
                else:
                    complete_input[col] = 0.0
            
            # Add categorical features
            for col in categorical_cols:
                if col in input_dict:
                    complete_input[col] = str(input_dict[col])
                else:
                    complete_input[col] = 'Unknown'
            
            # Add dummy target column (will not be used in prediction)
            complete_input[target_column] = 0
            
            print(f"   - Input features prepared: {len(complete_input)} columns")
            
            # ========================================
            # STEP 2: Convert to Spark DataFrame
            # ========================================
            print("   - Converting to Spark DataFrame...")
            
            # Create DataFrame from input dictionary
            input_df = self.spark.createDataFrame([complete_input])
            
            # ========================================
            # STEP 3: Apply Model Pipeline
            # ========================================
            print("   - Applying preprocessing and prediction...")
            
            # Transform input through the complete pipeline
            # This applies all preprocessing steps (indexing, assembling) and prediction
            prediction_df = self.model.transform(input_df)
            
            # ========================================
            # STEP 4: Extract Prediction Results
            # ========================================
            print("   - Extracting prediction results...")
            
            # Get prediction results
            result = prediction_df.select(
                "prediction",
                "probability"
            ).collect()[0]
            
            # Extract prediction (0 or 1)
            prediction = int(result['prediction'])
            
            # Extract probability vector
            probability = result['probability'].toArray()
            
            # Risk score is the probability of class 1 (default/high risk)
            # probability[0] = probability of class 0 (low risk)
            # probability[1] = probability of class 1 (high risk)
            risk_score = float(probability[1]) if len(probability) > 1 else float(probability[0])
            
            # Determine risk class
            if prediction == 1:
                risk_class = "High Risk"
                confidence = risk_score
            else:
                risk_class = "Low Risk"
                confidence = 1 - risk_score
            
            # ========================================
            # STEP 5: Prepare Response
            # ========================================
            response = {
                'risk_score': risk_score,
                'risk_percentage': risk_score * 100,
                'risk_class': risk_class,
                'prediction': prediction,
                'confidence': confidence,
                'confidence_percentage': confidence * 100,
                'low_risk_probability': float(probability[0]) if len(probability) > 1 else 1 - risk_score,
                'high_risk_probability': float(probability[1]) if len(probability) > 1 else risk_score
            }
            
            print("\n✅ Prediction completed!")
            print(f"   - Risk Class: {risk_class}")
            print(f"   - Risk Score: {risk_score:.4f} ({risk_score*100:.2f}%)")
            print(f"   - Confidence: {confidence:.4f} ({confidence*100:.2f}%)")
            
            return response
            
        except Exception as e:
            print(f"❌ Error during prediction: {str(e)}")
            import traceback
            traceback.print_exc()
            return {
                'error': f'Prediction failed: {str(e)}'
            }
    
    def get_feature_info(self):
        """
        Get information about expected features for prediction.
        
        Returns:
            dict: Dictionary containing feature information
        """
        if not self.is_loaded:
            if not self.load_model():
                return {}
        
        return {
            'numerical_features': self.metadata['numerical_cols'],
            'categorical_features': self.metadata['categorical_cols'],
            'target_column': self.metadata['target_column'],
            'total_features': len(self.metadata['numerical_cols']) + len(self.metadata['categorical_cols'])
        }
    
    def close(self):
        """Close the Spark session."""
        if self.spark:
            self.spark.stop()
            print("✅ Spark session closed")


# Global predictor instance
_predictor = None


def get_predictor():
    """
    Get or create the global predictor instance.
    
    Returns:
        RiskPredictor: Global predictor instance
    """
    global _predictor
    if _predictor is None:
        _predictor = RiskPredictor()
    return _predictor


def predict_risk(input_dict):
    """
    Convenience function to make predictions.
    
    Args:
        input_dict (dict): Dictionary containing feature values
    
    Returns:
        dict: Prediction results
    """
    predictor = get_predictor()
    return predictor.predict_risk(input_dict)


def get_feature_info():
    """
    Convenience function to get feature information.
    
    Returns:
        dict: Feature information
    """
    predictor = get_predictor()
    return predictor.get_feature_info()


if __name__ == "__main__":
    # This allows testing the module independently
    print("This module is designed to be imported by the Streamlit app.")
    print("Please run: streamlit run app.py")
    
    # Example usage (for testing purposes only)
    # predictor = RiskPredictor()
    # if predictor.load_model():
    #     test_input = {
    #         'age': 35,
    #         'income': 50000,
    #         'loan_amount': 10000,
    #         # Add other features as needed
    #     }
    #     result = predictor.predict_risk(test_input)
    #     print(result)
    #     predictor.close()
