"""
Simple test to verify PySpark installation and configuration
"""
import sys
import os

print("=" * 60)
print("Testing PySpark Configuration")
print("=" * 60)

# Set environment variables
os.environ['PYSPARK_SUBMIT_ARGS'] = '--master local[2] pyspark-shell'

try:
    from pyspark.sql import SparkSession
    from pyspark import SparkContext
    
    print("✅ PySpark imported successfully")
    
    # Stop any existing sessions
    try:
        SparkContext.getOrCreate().stop()
    except:
        pass
    
    try:
        SparkSession._instantiatedSession = None
    except:
        pass
    
    print("🔄 Creating Spark Session...")
    
    spark = SparkSession.builder \
        .appName("TestPySpark") \
        .master("local[2]") \
        .config("spark.driver.memory", "1g") \
        .config("spark.executor.memory", "1g") \
        .config("spark.sql.shuffle.partitions", "2") \
        .config("spark.driver.host", "localhost") \
        .config("spark.driver.bindAddress", "127.0.0.1") \
        .config("spark.sql.warehouse.dir", "file:///C:/temp/spark-warehouse") \
        .config("spark.local.dir", "C:/temp/spark-temp") \
        .getOrCreate()
    
    spark.sparkContext.setLogLevel("ERROR")
    
    print("✅ Spark Session created successfully!")
    print(f"   Spark Version: {spark.version}")
    print(f"   Master: {spark.sparkContext.master}")
    
    # Test with sample data
    print("\n🧪 Testing with sample data...")
    data = [("Alice", 25), ("Bob", 30), ("Charlie", 35)]
    df = spark.createDataFrame(data, ["Name", "Age"])
    
    print("✅ DataFrame created:")
    df.show()
    
    print(f"\n   Record count: {df.count()}")
    
    # Stop session
    spark.stop()
    print("\n✅ Spark Session stopped successfully")
    print("=" * 60)
    print("✅ PySpark is working correctly!")
    print("=" * 60)
    
except Exception as e:
    print(f"\n❌ Error: {str(e)}")
    import traceback
    traceback.print_exc()
    print("\n" + "=" * 60)
    print("❌ PySpark test failed!")
    print("=" * 60)
    sys.exit(1)
