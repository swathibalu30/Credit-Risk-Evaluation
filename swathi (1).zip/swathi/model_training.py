"""
Credit Risk Model Training Module
This module handles the complete PySpark ML pipeline for training a credit risk model.
"""

from pyspark.sql import SparkSession
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
from pyspark.ml import Pipeline
import os
import shutil


def train_model_from_csv(file_path, target_column='default'):
    """
    Train a credit risk prediction model from uploaded CSV dataset.
    
    Args:
        file_path (str): Path to the uploaded CSV file
        target_column (str): Name of the target column (default: 'default')
    
    Returns:
        dict: Dictionary containing evaluation metrics and model info
    """
    
    print("🚀 Starting model training process...")
    
    # ========================================
    # STEP 1: Initialize Spark Session
    # ========================================
    print("📊 Initializing Spark Session...")
    
    import os
    import findspark
    findspark.init()
    
    spark = SparkSession.builder \
        .appName("CreditRiskModel") \
        .master("local[*]") \
        .getOrCreate()
    
    # Set log level to reduce verbose output
    spark.sparkContext.setLogLevel("ERROR")
    
    # ========================================
    # STEP 2: Load Dataset
    # ========================================
    print(f"📂 Loading dataset from: {file_path}")
    df = spark.read.csv(file_path, header=True, inferSchema=True)
    
    print(f"✅ Dataset loaded successfully!")
    print(f"   - Total Records: {df.count()}")
    print(f"   - Total Columns: {len(df.columns)}")
    print(f"   - Columns: {df.columns}")
    
    # ========================================
    # STEP 3: Identify Target Column
    # ========================================
    # Auto-detect target column if not specified or not found
    possible_target_names = ['default', 'loan_status', 'status', 'target', 'label', 'outcome']
    
    if target_column not in df.columns:
        print(f"⚠️  Target column '{target_column}' not found. Auto-detecting...")
        for col_name in possible_target_names:
            if col_name in df.columns:
                target_column = col_name
                print(f"✅ Using '{target_column}' as target column")
                break
        else:
            # If no match found, use the last column
            target_column = df.columns[-1]
            print(f"⚠️  Using last column '{target_column}' as target")
    
    # ========================================
    # STEP 4: Data Preprocessing
    # ========================================
    print("\n🔧 Starting data preprocessing...")
    
    # Drop rows with missing target values
    df = df.filter(df[target_column].isNotNull())
    
    # Identify feature columns (exclude target)
    feature_columns = [col for col in df.columns if col != target_column]
    
    # Separate numerical and categorical columns
    numerical_cols = []
    categorical_cols = []
    
    for col in feature_columns:
        dtype = df.schema[col].dataType.typeName()
        if dtype in ['string']:
            categorical_cols.append(col)
        elif dtype in ['integer', 'long', 'double', 'float']:
            numerical_cols.append(col)
    
    print(f"   - Numerical columns: {numerical_cols}")
    print(f"   - Categorical columns: {categorical_cols}")
    
    # Handle missing values
    print("   - Handling missing values...")
    
    # For numerical columns: fill with mean
    for col in numerical_cols:
        mean_value = df.select(col).na.drop().agg({col: 'mean'}).collect()[0][0]
        if mean_value is not None:
            df = df.fillna({col: mean_value})
    
    # For categorical columns: fill with mode or 'Unknown'
    for col in categorical_cols:
        df = df.fillna({col: 'Unknown'})
    
    # ========================================
    # STEP 5: Feature Engineering Pipeline
    # ========================================
    print("\n🛠️  Building feature engineering pipeline...")
    
    # Create StringIndexers for categorical columns
    indexers = []
    indexed_cols = []
    
    for col in categorical_cols:
        indexer = StringIndexer(inputCol=col, outputCol=f"{col}_indexed", handleInvalid='keep')
        indexers.append(indexer)
        indexed_cols.append(f"{col}_indexed")
    
    # Create StringIndexer for target column
    target_indexer = StringIndexer(inputCol=target_column, outputCol="label", handleInvalid='keep')
    indexers.append(target_indexer)
    
    # Combine all feature columns for VectorAssembler
    all_feature_cols = numerical_cols + indexed_cols
    
    # Create VectorAssembler to combine all features
    assembler = VectorAssembler(
        inputCols=all_feature_cols,
        outputCol="features",
        handleInvalid='skip'
    )
    
    print(f"   - Total features: {len(all_feature_cols)}")
    
    # ========================================
    # STEP 6: Split Data into Train/Test
    # ========================================
    print("\n📊 Splitting data into train and test sets...")
    train_data, test_data = df.randomSplit([0.8, 0.2], seed=42)
    
    print(f"   - Training set size: {train_data.count()}")
    print(f"   - Test set size: {test_data.count()}")
    
    # ========================================
    # STEP 7: Train RandomForest Model
    # ========================================
    print("\n🌲 Training RandomForest Classifier...")
    
    # Initialize RandomForest classifier
    rf = RandomForestClassifier(
        featuresCol="features",
        labelCol="label",
        numTrees=100,
        maxDepth=10,
        seed=42
    )
    
    # Create complete pipeline
    pipeline = Pipeline(stages=indexers + [assembler, rf])
    
    # Train the model
    print("   - Training in progress... (this may take a few minutes)")
    model = pipeline.fit(train_data)
    print("   ✅ Model training completed!")
    
    # ========================================
    # STEP 8: Model Evaluation
    # ========================================
    print("\n📈 Evaluating model performance...")
    
    # Make predictions on test data
    predictions = model.transform(test_data)
    
    # Evaluate Accuracy
    accuracy_evaluator = MulticlassClassificationEvaluator(
        labelCol="label",
        predictionCol="prediction",
        metricName="accuracy"
    )
    accuracy = accuracy_evaluator.evaluate(predictions)
    
    # Evaluate AUC (Area Under ROC Curve)
    auc_evaluator = BinaryClassificationEvaluator(
        labelCol="label",
        rawPredictionCol="rawPrediction",
        metricName="areaUnderROC"
    )
    auc = auc_evaluator.evaluate(predictions)
    
    # Calculate Precision
    precision_evaluator = MulticlassClassificationEvaluator(
        labelCol="label",
        predictionCol="prediction",
        metricName="weightedPrecision"
    )
    precision = precision_evaluator.evaluate(predictions)
    
    # Calculate Recall
    recall_evaluator = MulticlassClassificationEvaluator(
        labelCol="label",
        predictionCol="prediction",
        metricName="weightedRecall"
    )
    recall = recall_evaluator.evaluate(predictions)
    
    # Calculate F1 Score
    f1_evaluator = MulticlassClassificationEvaluator(
        labelCol="label",
        predictionCol="prediction",
        metricName="f1"
    )
    f1_score = f1_evaluator.evaluate(predictions)
    
    print(f"\n✨ Model Performance Metrics:")
    print(f"   - Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   - AUC-ROC: {auc:.4f}")
    print(f"   - Precision: {precision:.4f}")
    print(f"   - Recall: {recall:.4f}")
    print(f"   - F1 Score: {f1_score:.4f}")
    
    # ========================================
    # STEP 9: Extract Feature Importance
    # ========================================
    print("\n📊 Extracting feature importance...")
    
    # Get the RandomForest model from pipeline
    rf_model = model.stages[-1]
    feature_importance = rf_model.featureImportances.toArray()
    
    # Create feature importance dictionary
    feature_importance_dict = {}
    for idx, importance in enumerate(feature_importance):
        if idx < len(all_feature_cols):
            feature_importance_dict[all_feature_cols[idx]] = float(importance)
    
    # Sort by importance
    sorted_features = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)
    
    print("   Top 5 Important Features:")
    for idx, (feature, importance) in enumerate(sorted_features[:5], 1):
        print(f"   {idx}. {feature}: {importance:.4f}")
    
    # ========================================
    # STEP 10: Save Model and Preprocessing Pipeline
    # ========================================
    print("\n💾 Saving model and preprocessing pipeline...")
    
    model_path = "risk_model"
    
    # Remove existing model if it exists
    if os.path.exists(model_path):
        shutil.rmtree(model_path)
    
    # Save the complete pipeline model
    model.write().overwrite().save(model_path)
    print(f"   ✅ Model saved to: {model_path}")
    
    # Save metadata for prediction
    metadata = {
        'target_column': target_column,
        'numerical_cols': numerical_cols,
        'categorical_cols': categorical_cols,
        'feature_columns': all_feature_cols,
        'all_columns': df.columns
    }
    
    import json
    with open('model_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    print("   ✅ Model metadata saved")
    
    # ========================================
    # STEP 11: Prepare Results
    # ========================================
    results = {
        'accuracy': float(accuracy),
        'auc': float(auc),
        'precision': float(precision),
        'recall': float(recall),
        'f1_score': float(f1_score),
        'feature_importance': dict(sorted_features),
        'train_size': train_data.count(),
        'test_size': test_data.count(),
        'total_features': len(all_feature_cols),
        'numerical_features': numerical_cols,
        'categorical_features': categorical_cols,
        'target_column': target_column
    }
    
    print("\n✅ Model training completed successfully!")
    
    # Stop Spark session
    spark.stop()
    
    return results


if __name__ == "__main__":
    # This allows testing the module independently
    print("This module is designed to be imported by the Streamlit app.")
    print("Please run: streamlit run app.py")
