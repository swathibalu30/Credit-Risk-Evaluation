"""
Credit Risk Model Training Module - Scikit-learn Version
This module uses scikit-learn instead of PySpark for better compatibility
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, roc_auc_score, precision_score, recall_score, f1_score
import joblib
import json
import os


def train_model_from_csv(file_path, target_column='default'):
    """
    Train a credit risk prediction model from uploaded CSV dataset using scikit-learn.
    
    Args:
        file_path (str): Path to the uploaded CSV file
        target_column (str): Name of the target column (default: 'default')
    
    Returns:
        dict: Dictionary containing evaluation metrics and model info
    """
    
    print("🚀 Starting model training process...")
    
    # ========================================
    # STEP 1: Load Dataset
    # ========================================
    print(f"📂 Loading dataset from: {file_path}")
    df = pd.read_csv(file_path)
    
    print(f"✅ Dataset loaded successfully!")
    print(f"   - Total Records: {len(df)}")
    print(f"   - Total Columns: {len(df.columns)}")
    print(f"   - Columns: {list(df.columns)}")
    
    # ========================================
    # STEP 2: Identify Target Column
    # ========================================
    possible_target_names = ['default', 'loan_status', 'status', 'target', 'label', 'outcome']
    
    if target_column not in df.columns:
        print(f"⚠️  Target column '{target_column}' not found. Auto-detecting...")
        for col_name in possible_target_names:
            if col_name in df.columns:
                target_column = col_name
                print(f"✅ Using '{target_column}' as target column")
                break
        else:
            target_column = df.columns[-1]
            print(f"⚠️  Using last column '{target_column}' as target")
    
    # ========================================
    # STEP 3: Data Preprocessing
    # ========================================
    print("\n🔧 Starting data preprocessing...")
    
    # Separate features and target
    X = df.drop(columns=[target_column])
    y = df[target_column]
    
    # Identify numerical and categorical columns
    numerical_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = X.select_dtypes(include=['object']).columns.tolist()
    
    print(f"   - Numerical columns: {numerical_cols}")
    print(f"   - Categorical columns: {categorical_cols}")
    
    # Handle missing values
    print("   - Handling missing values...")
    for col in numerical_cols:
        X[col].fillna(X[col].mean(), inplace=True)
    
    for col in categorical_cols:
        X[col].fillna('Unknown', inplace=True)
    
    # Encode categorical variables
    label_encoders = {}
    for col in categorical_cols:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col].astype(str))
        label_encoders[col] = le
    
    # ========================================
    # STEP 4: Split Data
    # ========================================
    print("\n📊 Splitting data into train and test sets...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"   - Training set size: {len(X_train)}")
    print(f"   - Test set size: {len(X_test)}")
    
    # ========================================
    # STEP 5: Train Model
    # ========================================
    print("\n🌲 Training RandomForest Classifier...")
    
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train, y_train)
    print("   ✅ Model training completed!")
    
    # ========================================
    # STEP 6: Evaluate Model
    # ========================================
    print("\n📈 Evaluating model performance...")
    
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    
    accuracy = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_pred_proba)
    precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
    
    print(f"\n✨ Model Performance Metrics:")
    print(f"   - Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   - AUC-ROC: {auc:.4f}")
    print(f"   - Precision: {precision:.4f}")
    print(f"   - Recall: {recall:.4f}")
    print(f"   - F1 Score: {f1:.4f}")
    
    # ========================================
    # STEP 7: Feature Importance
    # ========================================
    print("\n📊 Extracting feature importance...")
    
    feature_importance = dict(zip(X.columns, model.feature_importances_))
    sorted_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)
    
    print("   Top 5 Important Features:")
    for idx, (feature, importance) in enumerate(sorted_features[:5], 1):
        print(f"   {idx}. {feature}: {importance:.4f}")
    
    # ========================================
    # STEP 8: Save Model
    # ========================================
    print("\n💾 Saving model and preprocessing pipeline...")
    
    # Save model
    joblib.dump(model, 'risk_model.pkl')
    joblib.dump(label_encoders, 'label_encoders.pkl')
    
    # Save metadata
    metadata = {
        'target_column': target_column,
        'numerical_cols': numerical_cols,
        'categorical_cols': categorical_cols,
        'feature_columns': list(X.columns),
        'all_columns': list(df.columns)
    }
    
    with open('model_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("   ✅ Model saved successfully")
    
    # ========================================
    # STEP 9: Prepare Results
    # ========================================
    results = {
        'accuracy': float(accuracy),
        'auc': float(auc),
        'precision': float(precision),
        'recall': float(recall),
        'f1_score': float(f1),
        'feature_importance': dict(sorted_features),
        'train_size': len(X_train),
        'test_size': len(X_test),
        'total_features': len(X.columns),
        'numerical_features': numerical_cols,
        'categorical_features': categorical_cols,
        'target_column': target_column
    }
    
    print("\n✅ Model training completed successfully!")
    
    return results


if __name__ == "__main__":
    print("This module is designed to be imported by the Flask app.")
    print("Please run: python flask_app.py")
