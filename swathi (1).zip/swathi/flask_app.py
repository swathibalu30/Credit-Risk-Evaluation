"""
Flask Web Application for Credit Risk Evaluation
Run with: python flask_app.py
"""

from flask import Flask, render_template, request, jsonify, send_file, session
import os
import json
import pandas as pd
from datetime import datetime
import io
from werkzeug.utils import secure_filename
from model_training_sklearn import train_model_from_csv
from predict_sklearn import get_predictor

app = Flask(__name__)
app.secret_key = 'credit_risk_secret_key_2025'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max file size

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Global variables
training_status = {'status': 'idle', 'progress': 0, 'message': ''}
prediction_result = None


@app.route('/')
def index():
    """Home page"""
    model_exists = os.path.exists('risk_model') and os.path.exists('model_metadata.json')
    return render_template('index.html', model_exists=model_exists)


@app.route('/train')
def train_page():
    """Train model page"""
    return render_template('train.html')


@app.route('/predict')
def predict_page():
    """Prediction page"""
    if not os.path.exists('model_metadata.json'):
        return render_template('error.html', 
                             message='No model trained yet. Please train a model first.')
    
    with open('model_metadata.json', 'r') as f:
        metadata = json.load(f)
    
    return render_template('predict.html', 
                         numerical_cols=metadata.get('numerical_cols', []),
                         categorical_cols=metadata.get('categorical_cols', []))


@app.route('/upload_dataset', methods=['POST'])
def upload_dataset():
    """Handle dataset upload and training"""
    global training_status
    
    try:
        if 'dataset' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['dataset']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'Only CSV files are allowed'}), 400
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Get target column from request
        target_column = request.form.get('target_column', 'default')
        
        # Update training status
        training_status = {'status': 'training', 'progress': 10, 'message': 'Starting training...'}
        
        # Train model
        results = train_model_from_csv(filepath, target_column)
        
        # Clean up uploaded file
        os.remove(filepath)
        
        training_status = {'status': 'completed', 'progress': 100, 'message': 'Training completed!'}
        
        return jsonify({
            'success': True,
            'results': results,
            'message': 'Model trained successfully!'
        })
    
    except Exception as e:
        training_status = {'status': 'error', 'progress': 0, 'message': str(e)}
        return jsonify({'error': str(e)}), 500


@app.route('/training_status')
def get_training_status():
    """Get current training status"""
    return jsonify(training_status)


@app.route('/make_prediction', methods=['POST'])
def make_prediction():
    """Make prediction on input data"""
    global prediction_result
    
    try:
        input_data = request.json
        
        # Get predictor and make prediction
        predictor = get_predictor()
        result = predictor.predict_risk(input_data)
        
        if 'error' in result:
            return jsonify({'error': result['error']}), 500
        
        # Store result for download
        prediction_result = {
            'input': input_data,
            'result': result,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        return jsonify({
            'success': True,
            'prediction': result
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/download_prediction/<format>')
def download_prediction(format):
    """Download prediction results"""
    global prediction_result
    
    if prediction_result is None:
        return "No prediction available", 404
    
    try:
        # Prepare data
        data = {
            'Prediction Date': [prediction_result['timestamp']],
            'Risk Class': [prediction_result['result']['risk_class']],
            'Risk Score (%)': [f"{prediction_result['result']['risk_percentage']:.2f}"],
            'Confidence (%)': [f"{prediction_result['result']['confidence_percentage']:.2f}"],
            'Low Risk Probability (%)': [f"{prediction_result['result']['low_risk_probability']*100:.2f}"],
            'High Risk Probability (%)': [f"{prediction_result['result']['high_risk_probability']*100:.2f}"],
        }
        
        # Add input features
        for key, value in prediction_result['input'].items():
            data[f'Input: {key}'] = [value]
        
        df = pd.DataFrame(data)
        
        if format == 'csv':
            # Generate CSV
            output = io.BytesIO()
            df.to_csv(output, index=False)
            output.seek(0)
            
            filename = f"credit_risk_prediction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            return send_file(output, 
                           mimetype='text/csv',
                           as_attachment=True,
                           download_name=filename)
        
        elif format == 'excel':
            # Generate Excel
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name='Prediction')
            output.seek(0)
            
            filename = f"credit_risk_prediction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            return send_file(output,
                           mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                           as_attachment=True,
                           download_name=filename)
        else:
            return "Invalid format", 400
    
    except Exception as e:
        return f"Error: {str(e)}", 500


@app.route('/model_info')
def model_info():
    """Get model information"""
    try:
        if not os.path.exists('model_metadata.json'):
            return jsonify({'exists': False})
        
        with open('model_metadata.json', 'r') as f:
            metadata = json.load(f)
        
        return jsonify({
            'exists': True,
            'metadata': metadata
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    print("=" * 60)
    print("🚀 Credit Risk Evaluation System")
    print("=" * 60)
    print(f"📍 Server running at: http://127.0.0.1:5000")
    print(f"📂 Upload folder: {os.path.abspath(app.config['UPLOAD_FOLDER'])}")
    print(f"💡 Press Ctrl+C to stop the server")
    print("=" * 60)
    
    app.run(debug=True, host='127.0.0.1', port=5000)
