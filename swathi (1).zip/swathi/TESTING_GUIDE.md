# 🧪 Interactive UI Testing Checklist

## ✅ Testing Your New Interactive Features

Follow this checklist to test all the interactive enhancements added to your Credit Risk Evaluation system.

---

## 🚀 Getting Started

### 1. Start the Flask Server
```powershell
cd c:\Users\vishn\OneDrive\Desktop\swathi
python flask_app.py
```

### 2. Open Your Browser
Navigate to: **http://127.0.0.1:5000**

---

## 📋 Feature Testing Checklist

### **Home Page Tests** (`/`)

#### Hero Section
- [ ] Page loads with gradient background
- [ ] Title and subtitle are visible and centered
- [ ] "Get Started" button is present

#### Feature Cards (3 cards in a row)
- [ ] All 3 cards appear with fade-up animation as you scroll
- [ ] Cards appear with staggered timing (first, then second, then third)
- [ ] Each card has an icon at the top
- [ ] Icons are floating (moving up and down smoothly)

#### Card Hover Effects
- [ ] **Test 1**: Hover over first card (Upload Dataset)
  - Icon should float smoothly
  - Shimmer effect should sweep from left to right
  - Shadow should enhance
  - Card should lift slightly
  
- [ ] **Test 2**: Hover over second card (Train Model)
  - Same effects as Test 1
  
- [ ] **Test 3**: Hover over third card (Predict Risk)
  - Same effects as Test 1

#### Button Interactions
- [ ] Click "Upload Now" button
  - Ripple effect should spread from click point
  - Should navigate to /train page
  
- [ ] Click "Train Model" button
  - Ripple effect visible
  - Navigate to /train page
  
- [ ] Click "Make Prediction" button
  - Ripple effect visible
  - Navigate to /predict page

---

### **Navigation Bar Tests** (All pages)

#### Spark UI Button
- [ ] Yellow "Spark UI" button visible in top-right corner
- [ ] Button has fire icon (🔥)
- [ ] Button pulses with glow effect every 2 seconds
- [ ] Click button → Modal opens with slide-down animation
- [ ] Modal shows 4 info cards:
  - ML Engine: scikit-learn 1.7.2
  - Model Type: RandomForest
  - Backend: Flask 3.0.0
  - Performance: Fast & Efficient
- [ ] Click outside modal or X button → Modal closes smoothly

#### Navigation Links
- [ ] Hover over "Home" link
  - Link should lift up slightly (translateY -2px)
  - Color should change to primary blue
  
- [ ] Hover over "Train Model" link
  - Same lift and color effects
  
- [ ] Hover over "Predict Risk" link
  - Same lift and color effects
  
- [ ] Click navigation links
  - Smooth scrolling to target section (if on same page)
  - Immediate navigation (if different page)

---

### **Train Model Page Tests** (`/train`)

#### File Upload Section
- [ ] Page loads with animated upload area
- [ ] Drag-and-drop zone is visible
- [ ] "Choose File" button present

#### Upload Process
- [ ] Click "Choose File" and select `sample_credit_dataset.csv`
- [ ] Filename appears below button
- [ ] Click "Upload & Train" button
  - Ripple effect on button click
  - Loading spinner appears
  - Progress messages display
  
#### Training Results
- [ ] Success message appears with slide-in animation
- [ ] Training metrics displayed:
  - Accuracy
  - AUC-ROC
  - Precision
  - Recall
  - F1 Score
- [ ] Feature importance chart renders (Plotly interactive chart)
- [ ] Can hover over bars in chart
- [ ] Chart has zoom and pan controls

---

### **Predict Risk Page Tests** (`/predict`)

#### Form Section
- [ ] All input fields are visible
- [ ] Fields have proper labels and placeholders
- [ ] Dropdowns have appropriate options

#### Form Interaction
- [ ] Fill in sample values:
  - Age: 35
  - Income: 75000
  - Loan Amount: 25000
  - Credit Score: 720
  - Employment Type: Full-time
  - Education: Bachelor's
  - Loan Purpose: Home
  - Debt to Income Ratio: 0.35
  - Years Employed: 5
  - Number of Credit Lines: 4

- [ ] Click "Predict Risk" button
  - Ripple effect on button
  - Loading spinner appears
  - Form submits successfully

#### Results Display
- [ ] Results card appears with animation
- [ ] Risk class displayed (Low Risk/High Risk)
- [ ] Risk score shown as percentage
- [ ] Color-coded badge (green for low, red for high)
- [ ] Probability gauge visible
- [ ] Feature values listed

#### Download Buttons
- [ ] "Download CSV" button visible
  - Click button → Ripple effect
  - CSV file downloads
  
- [ ] "Download Excel" button visible
  - Click button → Ripple effect
  - Excel file downloads

---

## 🎨 Animation Quality Tests

### Smoothness Test
Scroll up and down the home page rapidly:
- [ ] Animations don't lag or stutter
- [ ] Cards appear smoothly
- [ ] No flickering or jumpy motion

### Ripple Effect Test
Click buttons rapidly 5 times:
- [ ] Each click creates a new ripple
- [ ] Ripples don't overlap incorrectly
- [ ] Old ripples disappear properly

### Hover Test
Hover on/off cards rapidly 10 times:
- [ ] Hover effects trigger consistently
- [ ] No delay in hover response
- [ ] Effects revert when mouse leaves

### Modal Test
Open and close Spark UI modal 5 times:
- [ ] Modal opens smoothly each time
- [ ] No flickering or jumping
- [ ] Close animation is smooth
- [ ] Backdrop fades correctly

---

## 📱 Responsive Design Tests

### Mobile View (Resize browser to 375px width)
- [ ] Navigation collapses to hamburger menu
- [ ] Cards stack vertically
- [ ] Animations still work smoothly
- [ ] Touch interactions work (if testing on mobile)
- [ ] Modal is responsive
- [ ] Form fields are easy to tap

### Tablet View (Resize browser to 768px width)
- [ ] Layout adjusts appropriately
- [ ] 2 cards per row (or appropriate layout)
- [ ] Navigation partially collapsed
- [ ] All animations work

### Desktop View (Full screen)
- [ ] 3 cards per row on home page
- [ ] Full navigation visible
- [ ] All effects and animations work perfectly

---

## 🔍 Browser Compatibility Tests

Test in multiple browsers if available:

### Chrome
- [ ] All animations work
- [ ] Ripple effects smooth
- [ ] Modal functions correctly
- [ ] No console errors

### Firefox
- [ ] All animations work
- [ ] CSS transitions smooth
- [ ] Modal functions correctly
- [ ] No console errors

### Edge
- [ ] All animations work
- [ ] No compatibility issues
- [ ] All features functional

### Safari (if available)
- [ ] Animations render correctly
- [ ] Webkit-specific features work
- [ ] No visual glitches

---

## ⚠️ Error Scenarios

### Network Issues
- [ ] Disable internet temporarily
  - CDN libraries should still be cached
  - Page should still be functional
  
### Missing Model
- [ ] Delete `risk_model.pkl` temporarily
- [ ] Try to make prediction
  - Proper error message displayed
  - Error animation shows

### Invalid Input
- [ ] Submit prediction form with empty fields
  - Validation messages appear
  - Form doesn't submit
  - No console errors

---

## 🎯 Performance Tests

### Page Load Speed
- [ ] Open DevTools → Network tab
- [ ] Reload page
- [ ] Check total load time
  - Should be under 3 seconds
  - All resources load successfully

### Animation Performance
- [ ] Open DevTools → Performance tab
- [ ] Record while scrolling and clicking
- [ ] Check FPS (frames per second)
  - Should maintain 60 FPS
  - No long tasks or jank

### Memory Usage
- [ ] Open DevTools → Memory tab
- [ ] Take heap snapshot
- [ ] Interact with site extensively
- [ ] Take another snapshot
  - No significant memory leaks
  - Memory usage stable

---

## 📊 Expected Results Summary

| Feature | Expected Behavior | Pass/Fail |
|---------|-------------------|-----------|
| Spark UI Button | Pulses every 2s, opens modal | ⬜ |
| Card Hover | Lifts + shadow + shimmer | ⬜ |
| Icon Float | Smooth up/down motion | ⬜ |
| Button Ripple | Spreads from click point | ⬜ |
| Modal Animation | Slides down smoothly | ⬜ |
| Smooth Scroll | Animated scroll to section | ⬜ |
| AOS Animations | Fade up on scroll | ⬜ |
| Nav Link Hover | Lifts and color change | ⬜ |
| Form Validation | Proper error messages | ⬜ |
| Loading Spinner | Shows during operations | ⬜ |
| Chart Interactivity | Hover, zoom, pan work | ⬜ |
| Download Buttons | Files download correctly | ⬜ |
| Mobile Responsive | Layout adapts properly | ⬜ |
| No Console Errors | Clean console log | ⬜ |

---

## 🐛 Common Issues & Solutions

### Issue: Animations not showing
**Solution**: 
1. Hard refresh (Ctrl + Shift + R)
2. Clear browser cache
3. Check console for JavaScript errors
4. Verify AOS.js loaded (check Network tab)

### Issue: Ripple effect not working
**Solution**:
1. Check jQuery is loaded
2. Verify no JavaScript conflicts
3. Inspect element for ripple class

### Issue: Modal not opening
**Solution**:
1. Check Bootstrap JS loaded
2. Verify modal ID matches function
3. Check browser console for errors

### Issue: Spark UI button not pulsing
**Solution**:
1. Check CSS animations enabled
2. Verify pulse-glow class exists
3. Check interval function running

---

## ✅ Final Checklist

Before considering testing complete:

- [ ] All features tested on at least one browser
- [ ] No console errors during normal usage
- [ ] All animations work smoothly
- [ ] Interactive elements responsive
- [ ] Modal opens and closes correctly
- [ ] Forms submit successfully
- [ ] Downloads work properly
- [ ] Mobile view tested (if applicable)
- [ ] Performance is acceptable
- [ ] No memory leaks detected

---

## 📝 Bug Report Template

If you find issues, document them using this format:

```
**Issue**: [Brief description]
**Page**: [e.g., Home page, Train page]
**Feature**: [e.g., Card hover effect]
**Browser**: [e.g., Chrome 120]
**Steps to Reproduce**:
1. [First step]
2. [Second step]
3. [Third step]

**Expected Behavior**: [What should happen]
**Actual Behavior**: [What actually happens]
**Console Errors**: [Any error messages]
**Screenshot**: [If applicable]
```

---

## 🎉 Success Criteria

Your interactive UI is working perfectly when:
- ✅ All animations are smooth (no jank)
- ✅ Ripple effects work on all buttons
- ✅ Spark UI modal opens/closes properly
- ✅ Cards respond to hover interactions
- ✅ Icons float smoothly
- ✅ Navigation links have hover effects
- ✅ Form submissions show loading states
- ✅ Charts are interactive
- ✅ Downloads work correctly
- ✅ No console errors
- ✅ Mobile layout is responsive

---

**Happy Testing! 🚀**

*If you encounter any issues, refer to the troubleshooting section or check the browser console for error messages.*
