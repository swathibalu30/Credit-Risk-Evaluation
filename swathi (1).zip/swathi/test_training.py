from model_training_sklearn import train_model_from_csv

print("\n" + "="*60)
print("Testing Model Training with Sample Dataset")
print("="*60 + "\n")

results = train_model_from_csv('sample_credit_dataset.csv')

print("\n" + "="*60)
print("✅ TRAINING SUCCESSFUL!")
print("="*60)
print(f"Accuracy: {results['accuracy']*100:.2f}%")
print(f"AUC-ROC: {results['auc']:.4f}")
print(f"Precision: {results['precision']:.4f}")
print(f"Recall: {results['recall']:.4f}")
print(f"F1 Score: {results['f1_score']:.4f}")
print("="*60)
