"""
Credit Risk Prediction Module - Scikit-learn Version
This module handles real-time prediction using trained scikit-learn model
"""

import pandas as pd
import numpy as np
import joblib
import json
import os


class RiskPredictor:
    """
    Class to handle credit risk predictions using saved scikit-learn model.
    """
    
    def __init__(self):
        """Initialize the predictor by loading saved model and metadata."""
        self.model = None
        self.label_encoders = None
        self.metadata = None
        self.is_loaded = False
    
    def load_model(self):
        """
        Load the saved model and metadata.
        
        Returns:
            bool: True if model loaded successfully, False otherwise
        """
        try:
            if not os.path.exists("risk_model.pkl"):
                print("❌ Model not found. Please train the model first.")
                return False
            
            print("📂 Loading trained model...")
            self.model = joblib.load("risk_model.pkl")
            self.label_encoders = joblib.load("label_encoders.pkl")
            
            with open('model_metadata.json', 'r') as f:
                self.metadata = json.load(f)
            
            print("✅ Model loaded successfully!")
            self.is_loaded = True
            return True
            
        except Exception as e:
            print(f"❌ Error loading model: {str(e)}")
            return False
    
    def predict_risk(self, input_dict):
        """
        Predict credit risk for a given input.
        
        Args:
            input_dict (dict): Dictionary containing feature values
        
        Returns:
            dict: Dictionary containing prediction results
        """
        
        if not self.is_loaded:
            print("⚠️  Model not loaded. Loading now...")
            if not self.load_model():
                return {'error': 'Model could not be loaded. Please train the model first.'}
        
        try:
            print("\n🔮 Making prediction...")
            
            # Get the feature columns in the exact order used during training
            feature_columns = self.metadata['feature_columns']
            numerical_cols = self.metadata['numerical_cols']
            categorical_cols = self.metadata['categorical_cols']
            
            # Create input dictionary with all features in correct order
            input_data = {}
            
            # Process each feature in the order they were used during training
            for col in feature_columns:
                if col in numerical_cols:
                    # Numerical feature
                    input_data[col] = float(input_dict.get(col, 0))
                elif col in categorical_cols:
                    # Categorical feature (needs encoding)
                    value = str(input_dict.get(col, 'Unknown'))
                    if col in self.label_encoders:
                        le = self.label_encoders[col]
                        try:
                            # Try to encode the value
                            input_data[col] = le.transform([value])[0]
                        except:
                            # If value not seen during training, use 0
                            input_data[col] = 0
                    else:
                        input_data[col] = 0
                else:
                    # Unknown column type, use 0
                    input_data[col] = 0
            
            # Create DataFrame with features in the exact order
            input_df = pd.DataFrame([input_data], columns=feature_columns)
            
            print(f"   - Input shape: {input_df.shape}")
            print(f"   - Input columns: {list(input_df.columns)}")
            
            # Make prediction
            prediction = int(self.model.predict(input_df)[0])
            probabilities = self.model.predict_proba(input_df)[0]
            
            # Prepare response
            risk_score = float(probabilities[1]) if len(probabilities) > 1 else float(probabilities[0])
            low_risk_prob = float(probabilities[0]) if len(probabilities) > 1 else 1 - risk_score
            high_risk_prob = float(probabilities[1]) if len(probabilities) > 1 else risk_score
            
            if prediction == 1:
                risk_class = "High Risk"
                confidence = high_risk_prob
            else:
                risk_class = "Low Risk"
                confidence = low_risk_prob
            
            response = {
                'risk_score': risk_score,
                'risk_percentage': risk_score * 100,
                'risk_class': risk_class,
                'prediction': prediction,
                'confidence': confidence,
                'confidence_percentage': confidence * 100,
                'low_risk_probability': low_risk_prob,
                'high_risk_probability': high_risk_prob
            }
            
            print(f"\n✅ Prediction completed!")
            print(f"   - Risk Class: {risk_class}")
            print(f"   - Risk Score: {risk_score:.4f} ({risk_score*100:.2f}%)")
            
            return response
            
        except Exception as e:
            print(f"❌ Error during prediction: {str(e)}")
            import traceback
            traceback.print_exc()
            return {'error': f'Prediction failed: {str(e)}'}
    
    def get_feature_info(self):
        """Get information about expected features."""
        if not self.is_loaded:
            if not self.load_model():
                return {}
        
        return {
            'numerical_features': self.metadata['numerical_cols'],
            'categorical_features': self.metadata['categorical_cols'],
            'target_column': self.metadata['target_column'],
            'total_features': len(self.metadata['numerical_cols']) + len(self.metadata['categorical_cols'])
        }


# Global predictor instance
_predictor = None


def get_predictor():
    """Get or create the global predictor instance."""
    global _predictor
    if _predictor is None:
        _predictor = RiskPredictor()
    return _predictor


def predict_risk(input_dict):
    """Convenience function to make predictions."""
    predictor = get_predictor()
    return predictor.predict_risk(input_dict)


def get_feature_info():
    """Convenience function to get feature information."""
    predictor = get_predictor()
    return predictor.get_feature_info()
