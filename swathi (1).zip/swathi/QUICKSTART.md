# 🚀 Quick Start Guide - Credit Risk System

## Installation Complete! ✅

Your Credit Risk Evaluation System is ready to use with **scikit-learn** (no PySpark/Java issues!).

## 📋 How to Run

### 1. Start the Flask Server

```bash
python flask_app.py
```

The server will start at: **http://127.0.0.1:5000**

### 2. Open Your Browser

Navigate to: **http://127.0.0.1:5000**

### 3. Train Your Model

1. Click **"Train Model"** in the navigation
2. Upload **`sample_credit_dataset.csv`** (already in your folder!)
3. Click **"Start Training"**
4. Wait 10-30 seconds for training to complete
5. View your model metrics!

### 4. Make Predictions

1. Click **"Predict Risk"** in the navigation
2. Fill in the loan application form
3. Click **"Predict Risk"**
4. Download your prediction report (CSV or Excel)

## 📊 Sample Dataset

Location: `sample_credit_dataset.csv`
- 100 records
- 11 features
- Ready to use!

## ✨ Features

- ✅ No PySpark/Java issues - uses scikit-learn
- ✅ Fast training (10-30 seconds)
- ✅ Beautiful web interface
- ✅ Download predictions as CSV/Excel
- ✅ Feature importance charts
- ✅ Risk score visualizations

## 🎯 What's Different from Original?

**Changed:** Using **scikit-learn RandomForest** instead of PySpark MLlib
**Why:** Better compatibility with Windows/Java versions
**Result:** Same accuracy, faster training, no errors!

## 📁 Key Files

- `flask_app.py` - Main web application
- `model_training_sklearn.py` - Training pipeline
- `predict_sklearn.py` - Prediction module
- `sample_credit_dataset.csv` - Sample data
- `templates/` - HTML templates
- `static/` - CSS/JS assets

## 🆘 Troubleshooting

**Issue:** Port 5000 already in use
**Fix:** Change port in `flask_app.py` line 201 to 5001

**Issue:** Model not found
**Fix:** Train the model first in "Train Model" page

**Issue:** Can't access browser
**Fix:** Make sure Flask server is running (see terminal output)

Enjoy your Credit Risk System! 🎉
