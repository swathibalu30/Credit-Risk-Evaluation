# 💳 Credit Risk Evaluation System

A complete **scikit-learn + Flask** application for predicting loan default risk using machine learning with a modern, interactive UI.

## ✨ NEW: Interactive UI v2.0

This system now features a **beautiful, modern interface** with smooth animations and delightful interactions:
- 🎨 Animate On Scroll effects
- 💫 Floating icon animations  
- 🌊 Material Design ripple effects
- ✨ Card shimmer and 3D hover effects
- 🔥 Interactive Spark UI modal
- 🎯 Smooth transitions and micro-interactions

**📚 Interactive UI Documentation:**
- [`SUMMARY.md`](SUMMARY.md) - Complete overview of v2.0 features
- [`UI_FEATURES.md`](UI_FEATURES.md) - Detailed feature documentation
- [`TESTING_GUIDE.md`](TESTING_GUIDE.md) - Comprehensive testing checklist
- [`COMPARISON.md`](COMPARISON.md) - Before/after analysis with metrics
- [`DEMO_SCRIPT.md`](DEMO_SCRIPT.md) - Presentation and demo guide

## 🌟 Features

- ✅ **Upload Custom Dataset**: Train models on your own CSV data
- 🤖 **scikit-learn ML Pipeline**: Automated preprocessing and model training
- 🎯 **RandomForest Classifier**: High-accuracy credit risk prediction
- 🌐 **Flask Web Application**: Modern, responsive interface with localhost deployment
- 📊 **Interactive Dashboard**: Real-time predictions with beautiful visualizations
- 🔄 **Dynamic Input Forms**: Automatically generated based on your dataset
- 📈 **Comprehensive Metrics**: Accuracy, AUC-ROC, Precision, Recall, F1 Score
- 🎨 **Feature Importance**: Visual insights into model decisions
- 💾 **Download Results**: Export predictions as CSV or Excel files
- ✨ **Interactive UI**: Smooth animations, ripple effects, and modern design

## 🚀 Quick Start

### Prerequisites

- Python 3.8 or higher
- Modern web browser (Chrome, Firefox, Edge, Safari)

### Installation

1. **Clone or navigate to the project directory:**
   ```bash
   cd c:\Users\vishn\OneDrive\Desktop\swathi
   ```

2. **Install required packages:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the Flask application:**
   ```bash
   python flask_app.py
   ```

4. **Open your browser** and navigate to:
   ```
   http://127.0.0.1:5000
   ```

## 📋 Dataset Requirements

Your CSV dataset should include:

- **Target Column**: Binary indicator for loan default
  - Common names: `default`, `loan_status`, `status`, `target`, `label`
  - Values: 0 (no default) or 1 (default)

- **Feature Columns**: 
  - **Numerical**: income, loan_amount, age, credit_score, debt_ratio, etc.
  - **Categorical**: employment_type, education, loan_purpose, etc.

### Example Dataset Structure

```csv
age,income,loan_amount,credit_score,employment_type,education,default
35,50000,10000,650,Full-time,Bachelor,0
42,75000,25000,720,Full-time,Master,0
28,30000,15000,580,Part-time,High School,1
```

## 🎯 How to Use

### Step 1: Train Model

1. Navigate to **"📊 Train Model"** in the sidebar
2. Click **"Upload Loan Dataset CSV"**
3. Select your dataset file
4. (Optional) Specify the target column name
5. Click **"🚀 Start Model Training"**
6. Wait for training to complete (2-5 minutes depending on dataset size)
7. Review model performance metrics

### Step 2: Make Predictions

1. Navigate to **"🔮 Make Predictions"** in the sidebar
2. Fill in the loan application details:
   - Numerical fields (income, loan amount, age, etc.)
   - Categorical fields (employment type, education, etc.)
3. Click **"🔮 Predict Credit Risk"**
4. View the risk assessment:
   - **Risk Score**: Probability of default (0-100%)
   - **Risk Class**: High Risk or Low Risk
   - **Confidence**: Model confidence in prediction
   - **Probability Breakdown**: Visual distribution

## 📁 Project Structure

```
credit_risk_project/
│
├── app.py                          # Streamlit web application
├── model_training.py               # PySpark model training pipeline
├── predict.py                      # PySpark prediction module
├── requirements.txt                # Python dependencies
├── README.md                       # This file
│
├── risk_model/                     # Trained model (auto-generated)
├── model_metadata.json             # Model information (auto-generated)
└── temp_dataset.csv                # Temporary upload (auto-deleted)
```

## 🔧 Technical Details

### Model Training Pipeline

1. **Data Loading**: PySpark reads CSV with schema inference
2. **Missing Value Handling**: 
   - Numerical: Filled with mean
   - Categorical: Filled with mode or 'Unknown'
3. **Feature Engineering**:
   - StringIndexer for categorical variables
   - VectorAssembler for feature combination
4. **Model Training**: RandomForestClassifier
   - 100 trees
   - Max depth: 10
   - 80/20 train-test split
5. **Evaluation**: Multiple metrics (Accuracy, AUC, Precision, Recall, F1)
6. **Model Persistence**: Saved for future predictions

### Prediction Pipeline

1. **Model Loading**: Loads saved PySpark pipeline
2. **Input Processing**: Converts user input to Spark DataFrame
3. **Preprocessing**: Applies saved transformations
4. **Prediction**: Generates risk score and classification
5. **Output**: Returns probability scores and risk class

## 📊 Model Metrics Explained

- **Accuracy**: Overall correct predictions (0-1)
- **AUC-ROC**: Model's ability to distinguish classes (0-1, higher is better)
- **Precision**: Accuracy of positive predictions
- **Recall**: Coverage of actual positive cases
- **F1 Score**: Harmonic mean of precision and recall

## 🎨 Features

### Interactive Dashboard
- Clean, modern UI with color-coded results
- Real-time model training and prediction
- Responsive design for all screen sizes

### Visualizations
- **Gauge Charts**: Risk score visualization
- **Bar Charts**: Model performance metrics
- **Feature Importance**: Top contributing features
- **Probability Breakdown**: Risk distribution

### Smart Detection
- Automatic target column detection
- Dynamic form generation based on dataset
- Intelligent missing value handling
- Error handling with detailed messages

## ⚠️ Important Notes

1. **No Mock Data**: The system requires you to upload a real dataset
2. **Training Time**: Depends on dataset size (typically 2-5 minutes)
3. **Java Requirement**: PySpark requires Java 8+ to be installed
4. **Memory**: Large datasets may require more RAM (4GB recommended)
5. **Model Persistence**: Trained model is saved and reused until retrained

## 🐛 Troubleshooting

### Issue: "Java not found" error
**Solution**: Install Java 8 or higher and set JAVA_HOME environment variable

### Issue: Training fails with memory error
**Solution**: Reduce dataset size or increase Spark memory in `model_training.py`

### Issue: Model not loading for predictions
**Solution**: Ensure model training completed successfully. Retrain if needed.

### Issue: Slow performance
**Solution**: 
- Close other applications
- Use a smaller dataset for testing
- Increase system RAM allocation

## 📦 Dependencies

```
pyspark==3.5.0          # Distributed computing and ML
streamlit==1.29.0       # Web application framework
pandas==2.1.4           # Data manipulation
numpy==1.26.2           # Numerical computing
scikit-learn==1.3.2     # ML utilities and metrics
matplotlib==3.8.2       # Plotting library
plotly==5.18.0          # Interactive visualizations
```

## 🔒 Security Notes

- Upload files are stored temporarily and deleted after training
- Model files are stored locally on your machine
- No data is sent to external servers
- All processing happens locally

## 📝 Sample Use Cases

1. **Bank Loan Approval**: Assess risk before approving loans
2. **Credit Card Issuance**: Evaluate applicant creditworthiness
3. **Portfolio Management**: Identify high-risk accounts
4. **Financial Planning**: Predict default probabilities
5. **Risk Analytics**: Understand key risk factors

## 🚀 Future Enhancements

- [ ] Support for multiple ML algorithms (XGBoost, Logistic Regression)
- [ ] Batch prediction from CSV file
- [ ] Model comparison and A/B testing
- [ ] Advanced feature engineering options
- [ ] Export predictions to CSV/Excel
- [ ] Integration with databases
- [ ] REST API for predictions

## 👥 Contributing

This is a complete production-ready system. Feel free to extend it with:
- Additional ML models
- Advanced preprocessing techniques
- More visualization options
- Integration with external data sources

## 📄 License

This project is provided as-is for educational and commercial use.

## 💡 Tips for Best Results

1. **Quality Data**: Use clean, well-formatted CSV files
2. **Balanced Dataset**: Ensure reasonable distribution of default/non-default cases
3. **Feature Selection**: Include relevant features (income, credit score, etc.)
4. **Sufficient Data**: At least 1000+ records recommended for training
5. **Regular Retraining**: Update model with new data periodically

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review error messages in the UI
3. Check Spark logs for detailed error information

---

**Built with ❤️ using PySpark and Streamlit**

**Version**: 1.0.0  
**Last Updated**: December 2025
